"use client";
import { FormEvent,useState } from "react";
import { createClient } from "@/lib/supabase/client";

export default function LoginPage(){
  const [email,setEmail]=useState(""),[password,setPassword]=useState(""),[error,setError]=useState(""),[busy,setBusy]=useState(false);

  async function handleLogin(event:FormEvent<HTMLFormElement>){
    event.preventDefault();setError("");setBusy(true);
    try{
      const supabase=createClient();
      const {data,error:loginError}=await supabase.auth.signInWithPassword({email:email.trim(),password});
      if(loginError){setError(loginError.message);setBusy(false);return}
      if(!data.session||!data.user){setError("Sign in was accepted, but Travel Crew could not create a session. Please try again.");setBusy(false);return}
      const {data:sessionCheck,error:sessionError}=await supabase.auth.getSession();
      if(sessionError||!sessionCheck.session){setError(sessionError?.message||"Travel Crew could not confirm your sign-in session.");setBusy(false);return}
      window.location.assign("/dashboard");
    }catch(err){
      setError(err instanceof Error?err.message:"Travel Crew could not sign you in. Please try again.");
      setBusy(false);
    }
  }

  return <main className="auth-page">
    <section className="auth-visual">
      <div className="brand-lockup"><div className="brand-mark">✈</div><div><div className="brand-name">Travel Crew</div><div>Plan • Explore • Share</div></div></div>
      <div><div className="eyebrow">Travel Crew</div><h1>One place for every part of your next adventure.</h1><p>Trips, itineraries, bookings, photos, documents, weather, travel money and group planning — built for your own private Travel Crew.</p></div>
      <div>Private friends & family travel planning</div>
    </section>
    <section className="auth-form-wrap"><div className="auth-card">
      <div className="eyebrow" style={{color:"#2458dc"}}>Welcome back</div><h2>Sign in</h2><p className="muted">Use your Travel Crew email and password.</p>
      <form className="form-stack" onSubmit={handleLogin}>
        <div className="field"><label htmlFor="email">Email</label><input id="email" type="email" autoComplete="email" inputMode="email" required value={email} onChange={e=>setEmail(e.target.value)}/></div>
        <div className="field"><label htmlFor="password">Password</label><input id="password" type="password" autoComplete="current-password" required value={password} onChange={e=>setPassword(e.target.value)}/></div>
        {error?<div className="error" role="alert">{error}</div>:null}
        <button className="primary" type="submit" disabled={busy}>{busy?"Signing in…":"Sign in to Travel Crew"}</button>
      </form>
    </div></section>
  </main>;
}
